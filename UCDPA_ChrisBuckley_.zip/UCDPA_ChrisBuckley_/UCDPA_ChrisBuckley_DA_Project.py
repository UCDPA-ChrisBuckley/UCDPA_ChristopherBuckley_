#!/usr/bin/env python
# coding: utf-8

# The dataset for the project can be found at the following link - https://www.kaggle.com/datasets/shivam2503/diamonds?datasetId=1312&sortBy=voteCount

# # Data Context

# The dataset contains data on 54,000 diamonds with price, carat, cut, colour, clarity, and various dimensions (x,y,z).
# 
# 1. Price - in USD $ 
# 2. Carat - diamond weight
# 3. Cut - quality of the cut (Fair - Ideal)
# 4. Colour - colour of diamond - J(worst) to D (Best)
# 5. Clarity - how clear the diamond is
# 6. X - length in mm
# 7. Y - width in mm
# 8. Z - depth in mm
# 9. Depth - total depth percentage
# 10. Table = width of top of diamond (widest point)

# # Project Scope

# The scope of this project is to determine if machine learning regression models can be used to predict the price of various diamonds based on other attributes given in the data set.
# 

# # Project Objectives

# The following objectives will be achieved to allow the project scope to be achieved.
# 
# 1. Import necessary libraries and packages
# 2. Load the dataset
# 3. Data Analysis
# 4. Pre-process the data for regression models
# 5. Build the regression models
# 6. Instantiate the models
# 7. Hyperparameter tuning (if required)
# 8. Determine model performance 
# 9. Interperate the data results

# # Importing Libraries

# In[217]:


# Dataframe operatonal libraries
import numpy as np
from numpy import median
from numpy import std
import pandas as pd
import math
import requests

# Visualization libraries
import seaborn as sns
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objects as go
from bs4 import BeautifulSoup as bs
import plotly.express as px # used for interactive visualizations
import plotly.graph_objects as go
from plotly.offline import init_notebook_mode, iplot # plot plotly graphs in line in a notebook
init_notebook_mode(connected = True)

# Web scraping library
from bs4 import BeautifulSoup as bs

# Machine Learning Models - regression & scoring/performance
from sklearn.preprocessing import OneHotEncoder, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import cross_val_score, KFold
from sklearn.model_selection import cross_val_predict
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import cross_validate
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import RandomizedSearchCV

from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Lasso
from sklearn.linear_model import Ridge
from sklearn.linear_model import RidgeCV
from sklearn.linear_model import ElasticNet
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.neighbors import KNeighborsRegressor
from sklearn.preprocessing import RobustScaler

from sklearn.model_selection import cross_val_score
from sklearn.metrics import mean_squared_error
from sklearn import metrics

from scipy.stats import shapiro
from scipy.stats import normaltest
from scipy.stats import chi2_contingency
from scipy.stats import chi2
import scipy.stats as stats

from sklearn.metrics import *



# # Demonstration of coding to utilize skills learned in course 

# Due to the nature of the dataset, some skills such as merging, dropping duplicates, changing data types etc, were not used.
# A small demonstration of skills could be used if there was a requirement for them.
# 
# After this section, the main project will begin.

# ## Other methods of manipulating the dataframe

# The chosen data frame doesn't require much manipulation of that data. Some of the code below indicates how changes would be made to the dataframe should it be required or further work be required.

# In[218]:


# Change data type

#df = df.astype({"carat":"string","table":"string"}, errors="ignore")


# In[219]:


# Replace or remove string elements

#df["carat"] = df["carat"].str.replace(",","") 


# In[220]:


# Rename columns

#df.rename(columns = {'carat':'Value'}, inplace = True)


# In[221]:


# Change data from string or object into date time

#df["carat"] = pd.to_datetime(df["carat"])


# In[222]:


# filter data to not include values

#df= df[df["carat"] != 0]


# In[223]:


# Create new columns in dataframe and insert the day, month and year into them

#df["carat"],df["carat"],sdf["carat"] = [df["carat"].dt.year,sdf["carat"].dt.month,df["carat"].dt.day]
#df["carat"] = pd.to_datetime(df["carat"], format='%m').dt.strftime('%b')


# In[224]:


# If extra information needed to be appended to the dataframe using a dictionary

#Prov = {'Donegal':"Ulster",'Monaghan':"Ulster",'Fermanagh':"Ulster",'Cavan':"Ulster",
       # "Longford":"Leinster","Meath":"Leinster","Westmeath":"Leinster","Louth":"Leinster","Dublin":"Leinster","Wicklow":"Leinster","Kildare":"Leinster","Offaly":"Leinster","Laois":"Leinster","Kilkenny":"Leinster","Carlow":"Leinster","Wexford":"Leinster",
      # "Leitrim":"Connacht","Sligo":"Connacht","Mayo":"Connacht","Roscommon":"Connacht","Galway":"Connacht",
       # "Waterford":"Munster","Tipperary":"Munster","Clare":"Munster","Limerick":"Munster","Cork":"Munster","Kerry":"Munster"}
    
# Create new column and append data

#df["new"] = df["carat"].map(Prov)


# ## Loading Data to show how merge works

# Original dataset is copied and columns removed in excel. The two files are then loaded as "A" & "B" and merged together on the "Unnamed" column to demonstrate merging

# In[225]:


# Importing split halfs A & B to merge
A = pd.read_csv(r"C:\Users\Chris\Desktop\Diamonds\A.csv")
A


# In[226]:


# Importing split halfs A & B to merge
B = pd.read_csv(r"C:\Users\Chris\Desktop\Diamonds\B.csv")
B


# In[227]:


# Merging the dataframes A & B using the "Unnamed" column

merge = A.merge(B, on = "Unnamed: 0")
merge


# ## Treating Duplicates

# In[228]:


# Duplicating the dataset and removing duplicates

merge2 = merge.copy()
duplicates = pd.concat([merge2,merge])
duplicates


# In[229]:


duplicates.info()


# In[230]:


# checking for duplicates (there should be double of each row)
duplicates.duplicated().sum()


# In[231]:


# Dropping Duplicates 
duplicates = duplicates.drop_duplicates()


# In[232]:


# Checking that the duplcates where successfully dropped
duplicates.duplicated().sum()


# # Regex 

# In[233]:


# Example of using REGEX to extract a pattern in data. 
# Looking to find email addresses that do not have ".com" at the end

# Import the re module
import re

regex = r"[A-Za-z0-9!#%&*\$\.]+@\w+\.com"

emails = ["s.chris.smith@hotmail.com", "96msmaith@hotmail.com", "!!!!!wad84wad1-=@msca.net"] 

for example in emails:
  	# Match the regex to the string
    if re.match(regex, example):
        # Complete the format method to print out the result
      	print("{email_example} is valid".format(email_example=example))
    else:
      	print("{email_example} is invalid".format(email_example=example))  


# In[ ]:





# In[ ]:





# In[ ]:





# # Main Project

# ## Loading Data

# The dataset comes in one single CSV file. As there isn't another dataset to merge with, the file was split into two sections ( in excel) and will be merged to show how merging/joining of datasets would be carried out.
# 
# The original dataset will then be used throughout the project.

# In[234]:


# Importing original dataset as variable df

df = pd.read_csv(r"C:\Users\Chris\Desktop\Diamonds\diamonds.csv")
df


# ## Data Analysis

# In[235]:


# view the dataframe
df


# In[236]:


# View top 10 rows of the dataframe
df.head(10)


# In[237]:


# View bottom 10 rows of dataframe
df.tail(10)


# In[238]:


# Checking for missing values and data types of variables
df.info()


# There are 53940 rows and 11 columns
# 
# There are 3 categorical variables ("Cut","Color","Clarity") and 7 numerical variables.
# 
# 

# In[239]:


# Checking for Nan / Missing Values

df.isnull().sum()


# In[240]:


df.duplicated().sum()


# There doesn't seem to be any missing or null values

# The column "Unnamed:0" seems to be copy of the index and is most likely unusable and will be dropped

# In[241]:


# Dropping the "Unnamed: 0" column
df = df.drop(["Unnamed: 0"], axis = 1)


# In[242]:


# Checking that drop was successful
df


# In[243]:


# Checking the statistical description of the data
df.describe()


# Observation:
# 
# The "Min" values for columns "X", "Y", "Z" are 0. This isn't possible as the diamonds require a value in each dimension.
# 

# In[244]:


# Investigate rows where the X Y Z values == 0
df.loc[(df["x"] == 0) | (df["y"] == 0) | (df["z"] == 0)]


# In[245]:


# Calculating the number of rows equal to 0
len(df.loc[(df["x"] == 0) | (df["y"] == 0) | (df["z"] == 0)])


# The 20 rows with values of 0 in X, Y or Z is roughly 0.04 % of the dataframe. It is safe to drop the rows and proceed with analysis. An alternative would be to impute the data based on various methods. However, for the small number of rows, dropping seems to be the best approach.

# In[246]:


# Dropping rows with X, Y, Z == 0
df = df[(df[["x","y","z"]] !=0).all(axis = 1)]


# In[247]:


# Checking that the dropping worked
df.loc[(df["x"] == 0) | (df["y"] == 0) | (df["z"] == 0)]


# In[ ]:





# ## Feature Engineering

# As the data provides measurements in the different axes "x","y","z", there may be some correlation in the volume of the diamonds and other features in the dataset
# 

# In[248]:


#creating a new column with the volume of each diamond
df["volume"] = df["x"] * df["y"] * df["z"]


# In[249]:


# checking that it worked
df


# In[250]:


# A quick check to view volumn compared with price
vol_price = sns.scatterplot(x = "volume", y = "price", data = df, hue="cut")
plt.title("Volume vs. Price")
plt.show()


# ## Data Visualization

# This section will seek to visualize the data from the dataset.
# 
# The objectives of this section are:
# 
# 1. Visualize the data to understand the features furhter
# 2. Identify any trends,correlations,relationships between the features in the dataset (uni and bivariate analysis)
# 3. Locate possible outliers and determine if they should be kept or removed
# 4. Determine the distributions of the data

# ### Visualizing the categorial data

# In[251]:


# Visualizing Price vs Cut
plt.figure(figsize=(10,8))
ax = sns.violinplot(x="cut",y="price", data=df,scale= "count")
ax.set_title("Cut vs. Price",  fontsize = 20)
ax.set_ylabel("Price",  fontsize = 15)
ax.set_xlabel("Cut",  fontsize = 15)
plt.show()


# The violin plot for Cut vs. Price shows that some data distributions on the "Ideal", "Premium", "Very Good" columns are most likely skewed. There are also possible outliers from a price of 10,000 and above. This will have to be determined.

# In[252]:


# Visualizing Colour vs Price
plt.figure(figsize=(10,8))
ax = sns.violinplot(x="color",y="price", data=df,scale= "count")
ax.set_title("Colour vs. Price",  fontsize = 20)
ax.set_ylabel("Price",  fontsize = 15)
ax.set_xlabel("Colour",  fontsize = 15)
plt.show()


# The violin plot for Colour vs. Price shows that the data distributions may be bimodal and/or skewed. This will have to be determined.

# In[253]:


# Visualizing Clarity vs Price
plt.figure(figsize=(10,8))
ax = sns.violinplot(x="clarity",y="price", data=df,scale= "count")
ax.set_title("Clarity vs. Price",  fontsize = 20)
ax.set_ylabel("Price",  fontsize = 15)
ax.set_xlabel("Clarity",  fontsize = 15)
plt.show()


# The violin plot for Clarity vs. Price shows that the data distributions are ranging from 0 to 10,000. Some distributions appear to be skewed and some normal. The distributions on the "I1" and "IF" plots seem to have rather small distributions and interquartile ranges. However, there seems to be outliers due to the large extended spikes in the plot. This will have to be determined.

# In[254]:


# Count the number of instances of each "cut"
sns.factorplot(x="cut", data=df , kind='count',aspect=2.5 )


# In[255]:


# Using box plots to determine the ranges of data within each "cut" feature
sns.factorplot(x="cut", y="price", data=df, kind="box" ,aspect=2.5 )


# In[256]:


# Group data to create a pie chart graph to help understand the percentage of each "cut" in the dataset
price_cut = pd.DataFrame(df.groupby("cut") ["price"].sum()).reset_index()


# In[257]:


fig = px.pie(df,
             values="price",
             names="cut",
             title="Cut as percentage of Price",
             color_discrete_sequence=px.colors.qualitative.G10
            )
# px.colors.qualitative.swatches().show() # see available color palettes

fig.update_traces(
                  textposition="inside",
                  textinfo="percent+label"
                 )
fig.update_layout(
                  margin=dict(l=10, r=100, b=10, t=70, pad=0),
                  titlefont = dict(size = 20)
                 )
iplot(fig)


# In[258]:


# Determine if there is a relationship between Price & Volume
lm = sns.lmplot(x="price", y="volume", data=df, line_kws={"color": "#8B4513"})
plt.title("Line Plot on Price vs Volume", color="#774571", fontsize = 20)
plt.show()


# There seems to be a linear relationship between price vs volume. This should also indicate a similar relationship with price vs x,y & z dimensions below. There are some possible outliers in the data.

# In[259]:


# Determine if there is a relationship between Price & Y
lm = sns.lmplot(x="price", y="y", data=df, line_kws={"color": "#8B4513"})
plt.title("Line Plot on Price vs Y", color="#774571", fontsize = 20)
plt.show()


# There seems to be a linear relationship between price vs Y. There are some possible outliers in the data.

# In[260]:


# Determine if there is a relationship between Price & X
lm = sns.lmplot(x="price", y="x", data=df, line_kws={"color": "#8B4513"})
plt.title("Line Plot on Price vs X", color="#774571", fontsize = 20)
plt.show()


# There seems to be a linear relationship between price vs Y. There are some possible outliers in the data, however, they don't seem ot be too extreme.

# In[261]:


# Determine if there is a relationship between Price & Z
lm = sns.lmplot(x="price", y="z", data=df, line_kws={"color": "#8B4513"})
plt.title("Line Plot on Price vs Z", color="#774571", fontsize = 20)
plt.show()


# There seems to be a linear relationship between price vs Z. There are some possible outliers in the data.

# In[262]:


# Determine if there is a relationship between Price & Depth
lm = sns.lmplot(x="price", y="depth", data=df, line_kws={"color": "#8B4513"})
plt.title("Line Plot on Price vs Depth", color="#774571", fontsize = 20)
plt.show()


# There seems to be a linear relationship between price vs Depth. There are some possible outliers in the data.

# In[263]:


# Determine if there is a relationship between Price & Table
lm = sns.lmplot(x="price", y="table", data=df, line_kws={"color": "#8B4513"})
plt.title("Line Plot on Price vs Table", color="#774571", fontsize = 20)
plt.show()


# There seems to be a linear relationship between price vs Table. There are some possible outliers in the data.

# In[264]:


# Gaining a large overview of the features and possible relationships
var = sns.pairplot(df, hue= "cut")


# The previous line plots of bivariate analysis vs. price showed that some features may have outliers. 
# 
# The pair plot above also shows the presence of outliers.
# 
# Some of the distributions of the features appear to be skewed and some appear to be normally distributed.
# 
# Certain fatures also seem to have a linear relationship, as seen above in the lineplots.
# 

# A for loop will be used to create bloxplots of each variable to try and get a more accurate view of the potential outliers.

# In[265]:


# Create boxplots for each numerical variable to determine if there are outliers
extra = 1
plt.figure(figsize=(15,10))
for i in ["carat","depth","table","price","x","y","z","volume"]:
        if extra<=8:
            plt.subplot(3,3,extra);
            extra+=1
            sns.boxplot(df[i]);
            plt.xlabel(i);
            


# As shown in the boxplots above, there are potential outliers in all of the numerical values.
# 
# There are two approaches that can be taken in this isntance.
# 
# 1. Removal of all data points that are outside the extremities of the boxplots
#    This would be considered to be the most "clinical" and could reduce the quantity of data significantly, especially in the      "depth" and "table" features.
# 2. The features could be capped to remove the most "extreme" outliers and retain most of the data points.
#    This is the preferred method.
#    
# If the effectiveness of the regression models is poor in the later stages of the project, approach no.1 above may be required to determine if the outliers are impacting the model in a significant way.
# 
# Approach 2 will be adopted and a hard limit on the data will be set, as shown below:
# 
# 1. Depth - remove outliers greater than 75 and lower than 45
# 2. Table - remove outliers greater than 80 and lower than 40
# 3. X - remove outliers greater than 40
# 4. Y - remove outliers greater than 40
# 5. Z - remove outliers greater than 40 and lower than 2
# 6. Volume - remove outliers greater than 1000

# In[266]:


# Capping Outliers

df = df[(df["depth"]<75)&(df["depth"]>45)]
df = df[(df["table"]<80)&(df["table"]>40)]
df = df[(df["x"]<30)]
df = df[(df["y"]<30)]
df = df[(df["z"]<30)&(df["z"]>2)]
df = df[(df["volume"]<1000)]
df.shape 


# In[267]:


# Cheking that the capping worked
extra = 1
plt.figure(figsize=(15,10))
for i in ["carat","depth","table","price","x","y","z","volume"]:
        if extra<=8:
            plt.subplot(3,3,extra);
            extra+=1
            sns.boxplot(df[i]);
            plt.xlabel(i);


# We can see that the capping of the outliers worked in the boxplots above.

# In[268]:


# Checking the variables using a pairplot again to view with the outliers removed
var = sns.pairplot(df, hue= "cut")


# In[ ]:





# # Web Scraping

# A new variable "top_10" was created into a dataframe to show the 10 most expensive diamonds from the dataset.
# 
# A table was scraped off the web using the package - BeautifulSoup.
# 
# The table was set as a figure on the website. BeautifulSoup was set up to scrape the figure and create a panads dataframe from it.
# 
# It was challenging to find a suitable table. Hoowever, it provides a contrast of price vs. carat to the project dataset.

# In[275]:


top_10 = df.sort_values(['price'], ascending=False).head(10)
top_10 = top_10.drop(columns=['depth','table','x','y','z','volume'])
top_10


# In[276]:


# Using BeautifulSoup to get a request to the URL
table = requests.get("https://www.diamonds.pro/education/diamond-prices/")
diamonds = bs(table.content, "lxml")


# In[277]:


# Finding the table in the element viewer in Google Chrome
table = diamonds.find("figure", {"class":"wp-block-table"}) 


# In[278]:


scrape = pd.read_html(str(table))[0]
# Using pandas "html read" function to return the table in a pandas data frame


# In[279]:


scrape = scrape.drop(["Diamond Example"], axis=1)


# In[280]:


scrape


# # Statistical Hypothesis Testing

# Hypothesis testing will be used on the data to determine the following:
# 
# 1. Is the average price of the diamonds different between "Premium" and "Good" types?
# 
# Each feature will be tested to determine if the distributions are normal. If they are normal, parametric statistical methods can be used on the features. If they are not normal, then nonparametric tests will be required.
# 
# Histograms will be used along with an ECDF function to determine a visual representation of the distributions.
# 
# Statistical methods will then be used to help determine the distiobutions and answer the hypothesis questions above.

# In[281]:


#ECDF Function
def ecdf(data):
    """Compute ECDF for a one-dimensional array of measurements."""
    # Number of data points: n
    n = len(data)

    # x-data for the ECDF: x
    x = np.sort(data)

    # y-data for the ECDF: y
    y = np.arange(1,n+1 ) / n

    return x, y


# In[282]:


percentiles = np.array([2.5,25,50,75,97.5])


# In[283]:


# Viewing the distributions of price

plt.figure(figsize=(11,7))
sns.distplot(df["price"], bins=150 ,hist_kws=dict(edgecolor = '#FF0000'))
plt.show()


# The distribution for price appears to be skewed and not normally distributed.

# In[284]:


# Plotting the theoretical and true ECDF of the price data

mu = np.mean(df["price"])
sigma = np.std(df["price"])
rng = np.random.default_rng(50)
samples = rng.normal(mu,sigma, size = 10000)
sales = np.percentile(df["price"], percentiles)
x_theor, y_theor = ecdf(samples)
x_price, y_price = ecdf(df["price"])
_ = plt.plot(x_price, y_price,marker = ".", linestyle = "none")
_ = plt.plot(x_theor, y_theor)
_ = plt.xlabel('Price')
_ = plt.ylabel('ECDF')
_ = plt.plot(sales, percentiles/100, marker='D', color='red',
         linestyle="none")
plt.show()


# In[285]:


# Viewing the distributions of carat

plt.figure(figsize=(11,7))
sns.distplot(df["carat"], bins=150 ,hist_kws=dict(edgecolor = '#FF0000'))
plt.show()


# The distribution for carat appears to be skewed and not normally distributed.

# In[286]:


# Viewing the Theoretical ECDF and actual ECDF of Carat
mu = np.mean(df["carat"])
sigma = np.std(df["carat"])
rng = np.random.default_rng(50)
samples = rng.normal(mu,sigma, size = 10000)
sales = np.percentile(df["carat"], percentiles)
x_theor, y_theor = ecdf(samples)
x_carat, y_carat = ecdf(df["carat"])
_ = plt.plot(x_carat, y_carat,marker = ".", linestyle = "none")
_ = plt.plot(x_theor, y_theor)
_ = plt.xlabel('carat')
_ = plt.ylabel('ECDF')
_ = plt.plot(sales, percentiles/100, marker='D', color='red',
         linestyle="none")
plt.show()


# In[287]:


# Viewing the distributions of depth

plt.figure(figsize=(11,7))
sns.distplot(df["depth"], bins=150 ,hist_kws=dict(edgecolor = '#FF0000'))
plt.show()


# The distribution for depth appears to be normally distributed.

# In[288]:


# Viewing the Theoretical ECDF and actual ECDF of Depth
mu = np.mean(df["depth"])
sigma = np.std(df["depth"])
rng = np.random.default_rng(50)
samples = rng.normal(mu,sigma, size = 10000)
sales = np.percentile(df["depth"], percentiles)
x_theor, y_theor = ecdf(samples)
x_depth, y_depth = ecdf(df["depth"])
_ = plt.plot(x_depth, y_depth,marker = ".", linestyle = "none")
_ = plt.plot(x_theor, y_theor)
_ = plt.xlabel('depth')
_ = plt.ylabel('ECDF')
_ = plt.plot(sales, percentiles/100, marker='D', color='red',
         linestyle="none")
plt.show()


# In[289]:


# Viewing the distributions of table

plt.figure(figsize=(11,7))
sns.distplot(df["table"], bins=150 ,hist_kws=dict(edgecolor = '#FF0000'))
plt.show()


# The distribution for table appears to be normally distributed.

# In[290]:


# Viewing the Theoretical ECDF and actual ECDF of Table
mu = np.mean(df["table"])
sigma = np.std(df["table"])
rng = np.random.default_rng(50)
samples = rng.normal(mu,sigma, size = 10000)
sales = np.percentile(df["table"], percentiles)
x_theor, y_theor = ecdf(samples)
x_table, y_table = ecdf(df["table"])
_ = plt.plot(x_table, y_table,marker = ".", linestyle = "none")
_ = plt.plot(x_theor, y_theor)
_ = plt.xlabel('table')
_ = plt.ylabel('ECDF')
_ = plt.plot(sales, percentiles/100, marker='D', color='red',
         linestyle="none")
plt.show()


# In[291]:


# Viewing the distributions of x

plt.figure(figsize=(11,7))
sns.distplot(df["x"], bins=150 ,hist_kws=dict(edgecolor = '#FF0000'))
plt.show()


# The distribution for x appears to be skewed and not normally distributed.

# In[292]:


# Viewing the Theoretical ECDF and actual ECDF of X
mu = np.mean(df["x"])
sigma = np.std(df["x"])
rng = np.random.default_rng(50)
samples = rng.normal(mu,sigma, size = 10000)
sales = np.percentile(df["x"], percentiles)
x_theor, y_theor = ecdf(samples)
x_x, y_x = ecdf(df["x"])
_ = plt.plot(x_x, y_x,marker = ".", linestyle = "none")
_ = plt.plot(x_theor, y_theor)
_ = plt.xlabel('x')
_ = plt.ylabel('ECDF')
_ = plt.plot(sales, percentiles/100, marker='D', color='red',
         linestyle="none")
plt.show()


# In[293]:


# Viewing the distributions of y

plt.figure(figsize=(11,7))
sns.distplot(df["y"], bins=150 ,hist_kws=dict(edgecolor = '#FF0000'))
plt.show()


# The distribution for y appears to be skewed and not normally distributed.

# In[294]:


# Viewing the Theoretical ECDF and actual ECDF of Y
mu = np.mean(df["y"])
sigma = np.std(df["y"])
rng = np.random.default_rng(50)
samples = rng.normal(mu,sigma, size = 10000)
sales = np.percentile(df["y"], percentiles)
x_theor, y_theor = ecdf(samples)
x_y, y_y = ecdf(df["y"])
_ = plt.plot(x_y, y_y,marker = ".", linestyle = "none")
_ = plt.plot(x_theor, y_theor)
_ = plt.xlabel('y')
_ = plt.ylabel('ECDF')
_ = plt.plot(sales, percentiles/100, marker='D', color='red',
         linestyle="none")
plt.show()


# In[295]:


# Viewing the distributions of z

plt.figure(figsize=(11,7))
sns.distplot(df["z"], bins=150 ,hist_kws=dict(edgecolor = '#FF0000'))
plt.show()


# The distribution for z appears to be skewed and not normally distributed.

# In[296]:


# Viewing the Theoretical ECDF and actual ECDF of Z
mu = np.mean(df["z"])
sigma = np.std(df["z"])
rng = np.random.default_rng(50)
samples = rng.normal(mu,sigma, size = 10000)
sales = np.percentile(df["z"], percentiles)
x_theor, y_theor = ecdf(samples)
x_z, y_z = ecdf(df["z"])
_ = plt.plot(x_z, y_z,marker = ".", linestyle = "none")
_ = plt.plot(x_theor, y_theor)
_ = plt.xlabel('z')
_ = plt.ylabel('ECDF')
_ = plt.plot(sales, percentiles/100, marker='D', color='red',
         linestyle="none")
plt.show()


# In[297]:


# Viewing the distributions of Volume
plt.figure(figsize=(11,7))
sns.distplot(df["volume"], bins=150 ,hist_kws=dict(edgecolor = '#FF0000'))
plt.show()


# In[298]:


# Viewing the Theoretical ECDF and actual ECDF of Volume
mu = np.mean(df["volume"])
sigma = np.std(df["volume"])
rng = np.random.default_rng(50)
samples = rng.normal(mu,sigma, size = 10000)
sales = np.percentile(df["volume"], percentiles)
x_theor, y_theor = ecdf(samples)
x_volume, y_volume = ecdf(df["volume"])
_ = plt.plot(x_volume, y_volume,marker = ".", linestyle = "none")
_ = plt.plot(x_theor, y_theor)
_ = plt.xlabel('volume')
_ = plt.ylabel('ECDF')
_ = plt.plot(sales, percentiles/100, marker='D', color='red',
         linestyle="none")
plt.show()


# ## Statistical Methods

# The Shapiro test will be used to determine if the distributions are Guassian.
# 
# The shapiro test may not be accurate for sample sizes over 5000, however, it is being used as a sanity check.

# In[299]:


X=["carat","depth","table","price","x","y","z","volume"]

dictionary= {elem : pd.DataFrame() for elem in X}

def shapiro_test(data):
    stat, p = shapiro(data)
    print("%s : Statistics=%.3f, p=%.3f" % (column,stat, p))
    alpha = 0.05
    if p > alpha:
        print("Sample looks Gaussian (We fail to reject H0)")
    else:
        print("Sample does not look Gaussian (We reject H0)")

for column in X:
    dictionary[column] = df[column]
    shapiro_test(dictionary[column])


# All of the tests run on the features has the null-hypothesis test rejected.
# 
# The use of a non-parameteric test (Mann-Whitney Test) will be used below.

# In[300]:


# Creating a new dataframe for cut and price
Cuts = df[["cut","price"]]
Cuts


# In[301]:


# Sorting the cuts into premium and good
premium = Cuts[Cuts["cut"]=="Premium"]
good = Cuts[Cuts["cut"]=="Good"]


# In[302]:


premium


# In[303]:


# Test for normality
stat, p = shapiro(premium.price)
print("Statistics=%.3f, p=%.3f" % (stat, p))
# interpret
alpha = 0.05
if p > alpha:
	print("Sample looks Gaussian (fail to reject H0)")
else:
	print("Sample does not look Gaussian (reject H0)")


# In[304]:


# Test for normality
stat, p = shapiro(good.price)
print("Statistics=%.3f, p=%.3f" % (stat, p))
# interpret
alpha = 0.05
if p > alpha:
	print("Sample looks Gaussian (fail to reject H0)")
else:
	print("Sample does not look Gaussian (reject H0)")


# In[305]:


# summarize
print("Premium: median = %.0f stdv = %.1f" % (median(premium.price), std(premium.price)))
print("Good: median = %.0f stdv = %.1f" % (median(good.price), std(good.price)))

print(stats.mannwhitneyu(premium.price, good.price))

if p > alpha:
	print('Means are not statistically different (We fail to reject H0)')
else:
	print('Means are statistically different (We reject H0)')    


# ## Feature Encoding of categorical variables

# At this stage the categorical variables as "objects" will be encoded into numerical features to allow further analysis and correlation testing

# In[306]:


# Creating a copy of the original dataset for encoding

df_encode = df.copy()


# In[307]:


# Encoding the categorical columns
columns = ['cut','color','clarity']
label_encoder = LabelEncoder()
for col in columns:
    df_encode[col] = label_encoder.fit_transform(df_encode[col])
df_encode.describe()


# In[308]:


# Create a correlation heatplot to determine correlation between the features
plt.figure(figsize=(18,14))
sns.heatmap(df_encode.corr(), annot=True, fmt='.2f')
plt.show()


# There seems to be a high correlation between the diamond dimensions and dimensions. Surprisingly, there is very low correlation between the categorial variables and price.

# In[ ]:





# # Feature Scaling

# The data will be split into two different groups - Training and Test.
# 
# This allows the chosen models to be applied. The "training" data will train the model and then the "test" data will be used to determine the effectiveness of the applied models.
# 
# As "price" is the target variable, it will be removed from the dataframe and used as the target variable for the model.
# 
# The train dataset will be assigned to "X" and the target variable "Price" will be assigned to "Y"

# In[309]:


df_ml = df_encode.copy()
df_ml


# ## Assigning the target variable

# In[310]:


# Creating X & Y
X = df_ml.drop(["price"], axis= 1).values
y = df_ml["price"].values


# ## Splitting data into train and test data
# 

# In[311]:


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.3, random_state = 66)


# In[312]:


sc = RobustScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)


# ## Instantiate Models with scaling

# In[313]:


# Setting up Linear Regression Model
regr = LinearRegression()
kf = KFold(n_splits=6, shuffle  = True, random_state = 42)
model = regr.fit(X_train, y_train)
accuracies = cross_val_score(estimator = regr, X = X_train, y = y_train, cv = kf,verbose = 1)
y_pred = model.predict(X_test)

print("RMSE: {}".format(np.sqrt(mean_squared_error((y_test),(y_pred)))))
print("R2  : {}".format(np.sqrt(r2_score((y_test),(y_pred)))))


# In[314]:


# Setting up Ridge Model
rid = Ridge()
kf = KFold(n_splits=6, shuffle  = True, random_state = 42)
model = rid.fit(X_train, y_train)
accuracies = cross_val_score(estimator = rid, X = X_train, y = y_train, cv = kf,verbose = 1)
y_pred = model.predict(X_test)

print("RMSE: {}".format(np.sqrt(mean_squared_error((y_test),(y_pred)))))
print("R2  : {}".format(np.sqrt(r2_score((y_test),(y_pred)))))


# In[315]:


# Setting up Random Forest Model
rf  = RandomForestRegressor()
kf = KFold(n_splits=6, shuffle  = True, random_state = 42)
rf.fit(X_train,y_train)
accuracies = cross_val_score(estimator = rf, X = X_train, y = y_train, cv = kf,verbose = 1)
y_pred = rf.predict(X_test)

print("RMSE: {}".format(np.sqrt(mean_squared_error((y_test),(y_pred)))))
print("R2  : {}".format(np.sqrt(r2_score((y_test),(y_pred)))))


# In[ ]:





# In[316]:


# Setting up Random Grid Search to see if tuning some hyperparmeters will change the accuracy of the model
n_estimators = [int(x) for x in np.linspace(10,200,10)]
max_depth = [int(x) for x in np.linspace(10,100,10)]
min_samples_split = [2,3,4,5,10]
min_samples_leaf = [1,2,4,10,15,20]
random_grid = {'n_estimators':n_estimators,'max_depth':max_depth,
               'min_samples_split':min_samples_split,'min_samples_leaf':min_samples_leaf}

random_grid


# In[317]:


rf = RandomForestRegressor()
rf_random = RandomizedSearchCV(estimator=rf,
                               param_distributions=random_grid,
                               cv = 3)

rf_random.fit(X_train,y_train)
y_pred = rf_random.predict(X_test)

print("RMSE: {}".format(np.sqrt(mean_squared_error((y_test),(y_pred)))))
print("R2  : {}".format(np.sqrt(r2_score((y_test),(y_pred)))))


# In[318]:


rf_random.best_params_


# In[320]:


rf = RandomForestRegressor(n_estimators=178,
                         min_samples_split=5,
                         min_samples_leaf=1,
                         max_depth=50)
rf.fit(X_train,y_train)
y_pred = rf.predict(X_test)

print("RMSE: {}".format(np.sqrt(mean_squared_error((y_test),(y_pred)))))
print("R2  : {}".format(np.sqrt(r2_score((y_test),(y_pred)))))


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




